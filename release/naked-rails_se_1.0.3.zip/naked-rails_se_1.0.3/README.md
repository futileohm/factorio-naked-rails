# Naked Rails: A Factorio Mod
Allows removing the gravel and sleepers from underneath the rails, making them transparent. Also allows changing normal or naked rails to remnant (destroyed) rails, and makes remnant rails stick around forever instead of disappearing after a set amount of time.

To use it, craft one of the planner items and drag it over the rails to modify like a blueprint. Shift-dragging will change rails back to normal rails, or remove remnant rails which cannot otherwise be mined.

Thanks to:  
ColonelWill and MojoD's train set map was the inspiration for the mod  
engie_99 for the name  
